module.exports = ({
name: "help",
usage: "\`+help (command name)\`",
description: "Shows all commands and if specified a command name shows the info of that command",
code: `$title[Help Menu]
$footer[$userTag[$authorID];$authorAvatar]
$description[> **Префикс для $serverName:** **\`\"$get[p]\"\`**]
$addField[$replaceText[$replaceText[$checkCondition[$message==];true;$get[helpn]];false;$get[cmdn]];$replaceText[$replaceText[$checkCondition[$message==];true;$get[help]];false;$get[cmd]];yes]
$let[helpn;> **Все команды**[$commandsCount]]
$let[help;> **Бот Инфо:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="BotInfo").map(x=>x.name).join(",$get[p]");yes]\`**
> **Общие:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="General").map(x=>x.name).join(",$get[p]");yes]\`**
> **Модерация:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="Moderation").map(x=>x.name).join(",$get[p]");yes]\`**
> **Разработчику:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="Developer").map(x=>x.name).join(",$get[p]");yes]\`**
> **Фан:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="Fun").map(x=>x.name).join(",$get[p]");yes]\`**
> **Музыка:**\n**\`$get[p]$djsEval[client.bot_commands.filter(x=>x.category =="Music").map(x=>x.name).join(",$get[p]");yes]\`**


Для получения дополнительной информации о конкретном типе команды **\`$get[p]help (command name)\`**.]
$let[cmdn;$replaceText[$replaceText[$checkCondition[$commandInfo[$message;name]!=];true;$get[cmn]];false;ERROR]
$let[cmd;$replaceText[$replaceText[$checkCondition[$commandInfo[$message;name]!=];true;$get[cm]];false;**Команды с таким именем не найдены!!**]
$let[cmn;> **$commandInfo[$message;name] Информация о команде**]
$let[cm;> **Псевдонимы**:\n$replaceText[$replaceText[$checkCondition[$commandInfo[$message;aliases]!=];true;$commandInfo[$message;aliases]];false;No aliases]
> **использование**:\n$commandInfo[$message;usage]
> **Описание**:\n**\`$commandInfo[$message;description]\`**
> **Категория**:\n**\`$commandInfo[$message;category]\`**]
$let[p;$getServerVar[prefix]]
$color[RANDOM]
$addTimestamp
$thumbnail[$userAvatar[$clientID]]`
});
