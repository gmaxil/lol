module.exports = ({
  name: "give-premium",
    usage: "+give-premium",
description: "Дает серверу премиум!!",
category: "Developer",
  code: `
   $title[Premium]
   $description[Успешно дал премиум серверу $serverName]
   $color[RANDOM]
   $onlyForIDs[$botOwnerID;Say Goodbye]`
})