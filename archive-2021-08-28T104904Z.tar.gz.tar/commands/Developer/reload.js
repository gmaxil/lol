module.exports = ({
    name: "refresh",
    aliases: "reload",
    usage: "\`+refresh\`",
    description: "Перезагружает все команды!!",
    category: "Developer",
    code: `$updateCommands Успешно обновил все команды!
$onlyForIDs[878513542876246056;:x: Вы не можете запустить эту команду]
$textSplit[$botOwnerID;,]`
});
