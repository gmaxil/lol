module.exports = ({
name: "reboot",
aliases: "restart",
usage: "\`+reboot\`",
description: "Перезагружает бота. Его ограничивают только разработчики бота!!",
category: "Developer",
code: `$reboot[Index.js]
$sendMessage[{field:**⚠️ Warning ⚠️**:**\`\`\`
Ручная перезагрузка началась $userTag[$authorID]!! Теперь перестану отвечать на все команды 1-2 мин.!\`\`\`**:yes}{color:RANDOM}{timestamp:ms}{thumbnail:$userAvatar[$clientID]};no]
$onlyForIDs[878513542876246056;:x: Вы не можете запустить эту команду]`
});
