module.exports = ({
    name: "aoi",
    usage: "+aoi <code>",
    description: "Оценивает коды aoijs. Доступно только разработчикам.!!",
    category: "Developer",
    code: `$eval[$message]
$onlyForIDs[878513542876246056;:x: You can't run this command]`
});
