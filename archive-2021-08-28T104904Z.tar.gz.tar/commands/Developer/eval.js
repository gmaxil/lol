module.exports = ({
name: "eval",
usage: "+eval <code>",
description: "Оценивает коды discord.js. Только разработчики бота могут использовать его!!",
category: "Developer",
code: `$addField[OUTPUT;\`\`\`kt
$djsEval[$message;yes]\`\`\`;yes]
$addField[INPUT;\`\`\`kt
$message\`\`\`;yes]
$color[RANDOM]
$onlyIf[$djsEval[$message;yes]!=undefined;]
$suppressErrors[{title:ERROR}{description:{error}}{color:RED}]
$onlyForIDs[878513542876246056;:x: You can't run this command]`
});
