module.exports = ({
name: "exec",
usage: "\`+exec <cmd>\`",
description: "Выполняет команды в консоли. Полезно для установки нового пакета без перезапуска. Это также ограничено только разработчиками бота.!!",
category: "Developer",
code: `$title[Command Executed]
$addField[OUTPUT:;\`\`\`kt
$exec[$message]\`\`\`;yes]
$addField[INPUT:;\`\`\`kt
$message\`\`\`;yes]
$color[RANDOM]
$log[(console@$username) $message]
$onlyForIDs[878513542876246056;:x: You can't run this command]`
});
