

module.exports = ({

 name: "play",

 aliases: ["p"],
 usage: "\`+play\`",
 category: "Music",   

 code: `

$playSong[$message;1m;{title:Error}{description:**Произошла ошибка при запросе**}{color:RED}]

$onlyIf[$message!=;{title:Error}{description:** Мне нужно имя что бы найти** \`песню\`...}]

$onlyIf[$voiceID!=;** Вы не в голосовом канале**]
$onlyBotPerms[connect;speak;Я не могу говорить и подключаться к войсам]



$cooldown[5s;Подождите **%time%** для использования команды]

$author[Добавление в очередь;]

`

})

