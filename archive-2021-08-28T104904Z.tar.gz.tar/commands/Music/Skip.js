module.exports = ({
name: "skip",
usage: "\`+skip\`",
category: "Music",   
code: `$skipSong $title[Успешно] $description[Вы успешно пропустили песню]

$onlyForIDs[$songInfo[userID];Вы не ставили песню]
$onlyIf[$voiceID[$clientID]!=;Я не в гс]
$onlyIf[$voiceID[$authorID]!=;Ты не в гс]
$onlyBotPerms[connect;speak;Я не могу говорить и подключаться к войсам]

$onlyIf[$queueLength!=0; Ничего не играет]`
    })