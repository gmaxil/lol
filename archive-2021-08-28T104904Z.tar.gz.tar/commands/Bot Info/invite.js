module.exports = ({
name: "invite",
usage: "\`+invite\`",
description: "invite.",
category: "BotInfo",
  code: `$title[My bot]
  $description[
   Recommended: [Click here]($getBotInvite)
   Admin: [Click here](https://discord.com/api/oauth2/authorize?client_id=879408712043888671&permissions=8&scope=bot)
  $footer[Спасибо что выбрал меня]`
});