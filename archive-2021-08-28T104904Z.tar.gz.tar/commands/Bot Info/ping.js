module.exports = ({
name: "ping",
usage: "\`+ping\`",
description: "Shows the Bot Latency and Websocket Latency.",
category: "BotInfo",
code: `Pinging...
$editIn[1s;🏓**Pong!**
**Bot Latency:** $botPingms
**Websocket Latency:** $pingms]`
});
