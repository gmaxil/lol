module.exports = ({
    name: "avatar",
    usage: "\`+avatar\`",
    description: "avatar",
    category: "General",
code: `
    $description[<@$findMember[$message]>'s avatar]
    $image[$userAvatar[$findMember[$message]]]
    $onlyIf[$checkContains[$channelType;text;news]==true;]`
});