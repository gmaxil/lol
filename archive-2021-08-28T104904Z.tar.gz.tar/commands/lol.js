module.exports=({
 name: "$alwaysExecute",
 code: `$channelSendMessage[$channelID;{title:Чувак, Втф?}{description:Этой команды не существует! Не пытайся сломить меня!}{color:RANDOM}]
$onlyIf[$commandinfo[$replaceText[$message[1];$getServerVar[prefix];];name]==;]
$onlyIf[$stringStartsWith[$message;$getServerVar[prefix]]!=false;]`
})