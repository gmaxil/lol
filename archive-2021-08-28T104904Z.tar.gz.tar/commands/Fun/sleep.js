module.exports = ({

name: "sleep",



 usage: "\`+sleep\`",

 category: "Fun",
    
code: `$title[Ya spat]

$footer[$userTag[$authorID];$authorAvatar]

$description[> **🛌УШЁЛ СПАТЬ. Просьба не пинговать!**
Споки...]`
});