module.exports = ({
name: "wanted",
usage: "\`+wanted\`",
category: "Fun",
code: `$title[В розыске $usertag[$finduser[$message]]] $image[https://someapi.dragonroyale.repl.co/wanted?avatar=$userAvatar[$findUser[$message]]]`
})