module.exports = ({
name: "gun",
usage: "\`+gun\`",
category: "Fun",

     code: `$image[https://api.devs-hub.xyz/gun?image=$userAvatar[$finduser[$message]]]

$color[$RANDOM]  `

    })