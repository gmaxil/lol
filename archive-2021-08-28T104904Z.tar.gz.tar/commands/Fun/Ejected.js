module.exports = ({
name: "ejected",
usage: "\`+ejected\`",
category: "Fun",
    code: `$color[$RANDOM]

$image[https://vacefron.nl/api/ejected?name=$replaceText[$username[$finduser[$message]]; ;+]&impostor=$randomText[true;false]&crewmate=$randomText[black;blue;brown;cyan;darkgreen;lime;orange;pink;purple;red;white;yellow]]`

}) 