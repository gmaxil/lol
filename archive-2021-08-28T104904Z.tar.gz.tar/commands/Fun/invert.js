module.exports = ({

name: "invert",



 usage: "\`+invert\`",

 category: "Fun", 
code: `$addTimestamp

$image[https://dinosaur.ml/overlay/invert/?image=$userAvatar[$mentioned[1;yes]]]

$title[Invert]

$color[RANDOM]`

});