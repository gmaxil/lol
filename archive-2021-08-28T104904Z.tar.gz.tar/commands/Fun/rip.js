module.exports = ({
name: "rip",
usage: "\`+rip\`",
category: "Fun",
code: `$image[https://vacefron.nl/api/grave?user=$userAvatar[$mentioned[1;yes]]]

$color[RANDOM]

$author[R.I.P $userTag[$mentioned[1;yes]]]`

})